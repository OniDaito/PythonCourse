  / \ / \ / \ / \ / \ / \ / \ / \ / \   / \ / \ / \ / \ / \ / \ 
 ( B | E | G | I | N | N | I | N | G ) ( P | Y | T | H | O | N )
  \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/   \_/ \_/ \_/ \_/ \_/ \_/ 
  
  By Benjamin 'oni' Blundell - oni@benjaminblundell.com
  
  14/11/10
  
  *PREREQUISITES*
  
  There are some things you'll need for the course before you start. Of couse, if you wish to learn outside the course, there are different things you can play with but I shall list as many as I can that I think are relevant to learning Python
  
  
  -> Windows

  	- Python 2.6.6 - http://www.python.org/download/releases/2.6.6/
  		- This version works well with lots of libraries (though you may wish to consider 2.7 if you are learning yourself)
  	
  	- Notepad ++ - http://notepad-plus-plus.org/
  		- This is a great editor under windows and works pretty well.
  		
  	- Pyglet Library - http://www.pyglet.org/download.html
  		- Another great little Library. It's a bit more lightweight than PyGame but doesn't seem to like Python 2.7 and above. Maybe this will change soon
  
  -> OSX (10.6)

	- Python 2.5 - This is already installed but you need to run it from the 'terminal.app' using the command 'python2.5'
	
	- Text Wrangler - http://www.barebones.com/products/textwrangler/
		- Its free as in Beer, which is great and it has a lot of functions. Cant be bad!
		
	- Pyglet Library - http://www.pyglet.org/download.html

  -> Linux
  	- Generally, this is up to your distribution.
  	- Under ubuntu you can do the following:
  		apt-get install python2.6
  		apt-get install python2.6-dev
  		apt-get install python-pyglet
  	
  	- You'll probably have a text editor you like already. Kate and Gedit are great for this sort of thing but emacs, vi, vim, nano, Komodo edit etc etc are all fine too!
  	
  
 *RESOURCES*
 
 You'll need to find out where to learn more about Python.I have included four useful files for you:
 
 	- 'Pythoncheat.png' is a simple cheat sheet that allows you to get to grips with Python quite easily though it is a little simple
 	
 	- 'pyglet_programming_guide.pdf' - this has some interesting and useful information on how to make pretty graphics using pyglet and python.
 	
 	- 'Python2point4cheat.pdf' is a much larger cheat sheet. It is for Python2.4 so it misses some of the newer things but overall its very complete and a lot is the same
 	
 	- 'Python_refcard.pdf' refers to 2.5 and isnt very pretty but might have some bits the others miss.
 	
 	
 Online, there are some ESSENTIAL webpages you can look at:
 
 	- http://wiki.python.org/moin/BeginnersGuide/NonProgrammers
	- http://docs.python.org/release/2.6.6/
	- http://docs.python.org/py3k/
	- http://docs.python.org/
	- http://www.pyglet.org/doc/programming_guide/index.html